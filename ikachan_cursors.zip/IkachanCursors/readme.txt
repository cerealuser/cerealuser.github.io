made by cerealuser2222222.

I didn't draw the "Ikachan_normal.cur" file but I modified it to make the other files